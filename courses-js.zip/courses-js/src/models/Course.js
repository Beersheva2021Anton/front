export default function createCourse(courseName, lecturerName, hoursNum, cost, 
    type, dayEvening, startDate) {
        return {courseName, lecturerName, hoursNum, cost, type, dayEvening, startDate};
}