import CoursesArray from "../services/courses-array";

export const courseProvider = new CoursesArray();