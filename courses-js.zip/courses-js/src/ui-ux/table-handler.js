export default class TableHandler {

    #keys; // fields of being displayed object
    #bodyElement;

    constructor(headerId, bodyId, keys, sortFun) {
        this.#keys = keys;
        const headerElement = document.getElementById(headerId);
        if (!headerElement) {
            throw 'Wrong header id';
        }
        this.#bodyElement = document.getElementById(bodyId);
        if (!this.#bodyElement){
            throw 'Wrong body id';
        }
        fillTableHeader(headerElement, keys, sortFun);

        if (sortFun){
            const columnsEl = document.querySelectorAll(`#${headerId} th`);
            columnsEl.forEach(c => c.addEventListener('click', 
                sortFun.bind(this, c.textContent)));
        }
    }
    clear() {
        this.#bodyElement.innerHTML = ' ';
    }
    addRow(obj, id) {
        this.#bodyElement.innerHTML += `<tr id="${id}">${this.#getRecordData(obj)}</tr>`;
    }
    #getRecordData(obj) {
        return this.#keys.map(k => `<td>${obj[k].constructor.name === "Date" ? 
            obj[k].toISOString().substr(0,10) : obj[k]}</td>`).join('');
    }
}

function fillTableHeader(headerElement, keys, sortFun) {
    headerElement.innerHTML = getColumns(keys, sortFun);
}

// function getColumns(keys, sortFnName){
//     return keys.map(key => {
//         return !sortFnName ? `<th>${key}</th>` :
//          `<th style="cursor: pointer" onclick="${sortFnName}('${key}')">${key}</th>`
//     }).join('');
// }

function getColumns(keys, sortFun) {
    return keys.map(key => {
        return !sortFun ? `<th>${key}</th>` 
            : `<th style="cursor: pointer">${key}</th>`;
    }).join('');
}