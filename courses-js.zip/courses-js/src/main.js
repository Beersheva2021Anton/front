import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle";
import { getRandomElement, getRandomInteger, getRandomDate } from "./utilities/random";
import courseData from "./config/courseData.json";
import College from "./services/college";
import { courseProvider } from "./config/servicesConfig";
import createCourse from "./models/Course";
import FormHandler from "./ui-ux/form-handler";
import TableHandler from "./ui-ux/table-handler";

const N_RANDOM_COURSES = 20;
const college = new College(courseProvider, courseData);
createRandomCourses(college, N_RANDOM_COURSES);
debugDisplayCollege(college);

function createRandomCourses(college, nCourses) {
    for (let i = 0; i < nCourses; i++){
        let courseName = getRandomElement(courseData.courseNames);
        let lecturerName = getRandomElement(courseData.lecturers);
        let hours = getRandomInteger(courseData.minHours, courseData.maxHours);
        let cost = getRandomInteger(courseData.minCost, courseData.maxCost);
        let type = getRandomElement(courseData.types);
        let timingInd = getRandomInteger(0, courseData.timing.length);
        let timing = timingInd < courseData.timing.length ? 
            [courseData.timing[timingInd]] : courseData.timing;
        let startDate = getRandomDate(courseData.minYear, courseData.maxYear);

        let course = createCourse(courseName, lecturerName, hours, cost, type, timing, startDate);
        college.addCourse(course);
    }
}

function debugDisplayCollege(college) {    
    college.getAllCourses().forEach(element => {
        console.log(JSON.stringify(element));
    });
}

// const formCourse = new FormHandler('course-form', 'alert');
// FormHandler.fillOptions('course-name', courseData.courseNames);
// FormHandler.fillOptions('lecturer-name', courseData.lecturers);
// formCourse.addHandler(college.addCourse.bind(college));

const coursesSort = function(key) {
    tableCourses.clear();
    college.sort(key).forEach(c => tableCourses.addRow(c, c.id));
}
const tableCourses = new TableHandler('courses-header', 'courses-body', 
    ['id', 'courseName', 'lecturerName', 'hoursNum', 'cost', 'startDate'], coursesSort);
college.getAllCourses().forEach(c => tableCourses.addRow(c, c.id));